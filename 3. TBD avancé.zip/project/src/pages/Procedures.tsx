import React from 'react';
import { Plus } from 'lucide-react';
import TaskList from '../components/TaskList';
import TaskForm from '../components/TaskForm';
import Modal from '../components/Modal';
import { Task } from '../types/types';

const Procedures = () => {
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [tasks, setTasks] = React.useState<Task[]>([
    {
      id: '1',
      title: 'Appel d\'offres - Équipements informatiques',
      description: 'Acquisition de nouveaux équipements informatiques pour le service technique',
      status: 'published',
      priority: 'high',
      dueDate: '2024-04-15',
      budget: 50000,
      assignedTo: 'Marie Lambert',
      documents: [],
      createdAt: '2024-03-01T10:00:00',
      updatedAt: '2024-03-05T15:30:00',
    },
    {
      id: '2',
      title: 'Marché de services - Maintenance préventive',
      description: 'Contrat de maintenance préventive pour les installations techniques',
      status: 'review',
      priority: 'medium',
      dueDate: '2024-03-30',
      budget: 25000,
      assignedTo: 'Pierre Martin',
      documents: [],
      createdAt: '2024-03-02T09:00:00',
      updatedAt: '2024-03-04T11:20:00',
    },
  ]);

  const handleCreateTask = (data: Partial<Task>) => {
    const newTask: Task = {
      ...data,
      id: Math.random().toString(36).substr(2, 9),
      documents: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as Task;

    setTasks((prev) => [...prev, newTask]);
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Marchés</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-5 h-5" />
          Nouveau marché
        </button>
      </div>

      <TaskList tasks={tasks} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Nouveau marché"
      >
        <TaskForm
          onSubmit={handleCreateTask}
          onCancel={() => setIsModalOpen(false)}
        />
      </Modal>
    </div>
  );
};

export default Procedures;