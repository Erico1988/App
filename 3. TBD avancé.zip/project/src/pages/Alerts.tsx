import React from 'react';
import { AlertTriangle, Clock, Calendar, Bell } from 'lucide-react';

const Alerts = () => {
  const alerts = [
    {
      id: 1,
      title: 'Date limite approchante',
      description: 'Le marché "Équipements informatiques" arrive à échéance dans 3 jours',
      type: 'deadline',
      severity: 'high',
      date: '2024-03-05T10:30:00',
    },
    {
      id: 2,
      title: 'Validation requise',
      description: 'Nouvelle demande de validation en attente pour le marché de maintenance',
      type: 'validation',
      severity: 'medium',
      date: '2024-03-05T09:15:00',
    },
    {
      id: 3,
      title: 'Dépassement budgétaire',
      description: 'Le budget alloué au marché de formation a été dépassé de 10%',
      type: 'budget',
      severity: 'high',
      date: '2024-03-04T16:45:00',
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Alertes</h1>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Bell className="w-5 h-5" />
          Configurer les notifications
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="space-y-6">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-start gap-4 p-4 border rounded-lg hover:bg-gray-50"
            >
              <div className={`p-2 rounded-lg ${
                alert.severity === 'high' ? 'bg-red-100' : 'bg-yellow-100'
              }`}>
                <AlertTriangle className={`w-6 h-6 ${
                  alert.severity === 'high' ? 'text-red-600' : 'text-yellow-600'
                }`} />
              </div>

              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold">{alert.title}</h3>
                    <p className="text-gray-600">{alert.description}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${getSeverityColor(alert.severity)}`}>
                    {alert.severity === 'high' ? 'Urgent' : 'Important'}
                  </span>
                </div>

                <div className="mt-4 flex items-center gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(alert.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{new Date(alert.date).toLocaleTimeString()}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Alerts;