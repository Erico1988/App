import React from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

const Planning = () => {
  const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  const currentMonth = 'Mars 2024';

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Planning</h1>

      <div className="bg-white rounded-lg shadow-md">
        <div className="p-4 flex items-center justify-between border-b">
          <div className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-semibold">{currentMonth}</h2>
          </div>
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-4">
          <div className="grid grid-cols-7 gap-2 mb-2">
            {days.map(day => (
              <div key={day} className="text-center text-sm font-medium text-gray-600">
                {day}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: 35 }).map((_, i) => {
              const day = i + 1;
              const hasEvent = [5, 12, 19, 25].includes(day);
              return (
                <div
                  key={i}
                  className={`aspect-square p-2 rounded-lg border ${
                    hasEvent ? 'bg-blue-50 border-blue-200' : 'hover:bg-gray-50'
                  }`}
                >
                  <span className="text-sm">{day}</span>
                  {hasEvent && (
                    <div className="mt-1">
                      <div className="text-xs bg-blue-100 text-blue-800 rounded px-1 py-0.5">
                        Échéance
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">Échéances du mois</h2>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
              <div>
                <p className="font-medium">Marché #{i}</p>
                <p className="text-sm text-gray-600">Date limite: 15/03/2024</p>
              </div>
              <span className="px-3 py-1 rounded-full text-sm bg-yellow-100 text-yellow-800">
                À venir
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Planning;