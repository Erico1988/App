import React from 'react';
import { Mail, Phone, User } from 'lucide-react';

const Team = () => {
  const team = [
    {
      id: 1,
      name: 'Marie Lambert',
      role: 'Chef de projet',
      email: 'marie.lambert@example.com',
      phone: '+33 6 12 34 56 78',
      assignedTasks: 5,
    },
    {
      id: 2,
      name: 'Pierre Martin',
      role: 'Responsable juridique',
      email: 'pierre.martin@example.com',
      phone: '+33 6 23 45 67 89',
      assignedTasks: 3,
    },
    {
      id: 3,
      name: 'Sophie Dubois',
      role: 'Analyste financier',
      email: 'sophie.dubois@example.com',
      phone: '+33 6 34 56 78 90',
      assignedTasks: 4,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Équipe</h1>
        <button className="btn btn-primary">Ajouter un membre</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {team.map((member) => (
          <div key={member.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-gray-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">{member.name}</h3>
                <p className="text-gray-600">{member.role}</p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-600">
                <Mail className="w-4 h-4" />
                <span className="text-sm">{member.email}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-600">
                <Phone className="w-4 h-4" />
                <span className="text-sm">{member.phone}</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Tâches assignées</span>
                <span className="px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800">
                  {member.assignedTasks}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Team;