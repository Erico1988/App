import React from 'react';
import { Bell, Lock, User, Globe, Mail } from 'lucide-react';

const Settings = () => {
  const sections = [
    {
      id: 'profile',
      title: 'Profil',
      icon: User,
      fields: [
        { label: 'Nom', value: 'Jean Dupont', type: 'text' },
        { label: 'Email', value: 'jean.dupont@example.com', type: 'email' },
        { label: 'Téléphone', value: '+33 6 12 34 56 78', type: 'tel' },
      ],
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: Bell,
      fields: [
        { label: 'Notifications par email', value: true, type: 'toggle' },
        { label: 'Notifications push', value: true, type: 'toggle' },
        { label: 'Résumé hebdomadaire', value: false, type: 'toggle' },
      ],
    },
    {
      id: 'security',
      title: 'Sécurité',
      icon: Lock,
      fields: [
        { label: 'Authentification à deux facteurs', value: false, type: 'toggle' },
        { label: 'Changer le mot de passe', type: 'button' },
        { label: 'Sessions actives', type: 'button' },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Paramètres</h1>

      <div className="grid grid-cols-1 gap-6">
        {sections.map((section) => (
          <div key={section.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-blue-100 rounded-lg">
                <section.icon className="w-5 h-5 text-blue-600" />
              </div>
              <h2 className="text-lg font-semibold">{section.title}</h2>
            </div>

            <div className="space-y-4">
              {section.fields.map((field, index) => (
                <div key={index} className="flex items-center justify-between py-2">
                  <label className="text-gray-700">{field.label}</label>
                  {field.type === 'toggle' ? (
                    <button
                      className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                        field.value ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                          field.value ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  ) : field.type === 'button' ? (
                    <button className="px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                      Modifier
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <input
                        type={field.type}
                        value={field.value}
                        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                        readOnly
                      />
                      <button className="text-blue-600 hover:bg-blue-50 p-2 rounded-lg">
                        Modifier
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Settings;