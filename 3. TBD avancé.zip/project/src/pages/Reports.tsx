import React from 'react';
import { BarChart2, PieChart, TrendingUp, Download } from 'lucide-react';

const Reports = () => {
  const reports = [
    {
      id: 1,
      title: 'Synthèse mensuelle',
      description: 'Rapport détaillé des marchés du mois en cours',
      type: 'monthly',
      icon: BarChart2,
    },
    {
      id: 2,
      title: 'Analyse budgétaire',
      description: 'État des dépenses et allocations budgétaires',
      type: 'financial',
      icon: PieChart,
    },
    {
      id: 3,
      title: 'Tendances et prévisions',
      description: 'Analyse des tendances et projections',
      type: 'trends',
      icon: TrendingUp,
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Rapports</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((report) => (
          <div key={report.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <report.icon className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold">{report.title}</h3>
                <p className="text-sm text-gray-600">{report.description}</p>
              </div>
            </div>

            <button className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50">
              <Download className="w-4 h-4" />
              Télécharger
            </button>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">Historique des rapports</h2>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
              <div>
                <p className="font-medium">Rapport #{i}</p>
                <p className="text-sm text-gray-600">Généré le 0{i}/03/2024</p>
              </div>
              <button className="flex items-center gap-2 px-3 py-1 text-sm text-blue-600 hover:bg-blue-50 rounded-lg">
                <Download className="w-4 h-4" />
                PDF
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Reports;