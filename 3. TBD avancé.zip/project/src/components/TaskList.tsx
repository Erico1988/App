import React from 'react';
import { Task } from '../types/types';
import TaskCard from './TaskCard';
import { Filter } from 'lucide-react';

interface TaskListProps {
  tasks: Task[];
  onFilterChange?: (filters: any) => void;
}

const TaskList: React.FC<TaskListProps> = ({ tasks, onFilterChange }) => {
  const [sortBy, setSortBy] = React.useState('dueDate');
  const [filterStatus, setFilterStatus] = React.useState<string[]>([]);

  const statuses = ['draft', 'review', 'published', 'awarded', 'completed'];

  const handleStatusFilter = (status: string) => {
    setFilterStatus(prev => 
      prev.includes(status) 
        ? prev.filter(s => s !== status)
        : [...prev, status]
    );
  };

  const filteredTasks = React.useMemo(() => {
    let filtered = [...tasks];
    
    if (filterStatus.length > 0) {
      filtered = filtered.filter(task => filterStatus.includes(task.status));
    }
    
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'dueDate':
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case 'budget':
          return b.budget - a.budget;
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        default:
          return 0;
      }
    });
    
    return filtered;
  }, [tasks, filterStatus, sortBy]);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm">
        <div className="flex items-center gap-4">
          <Filter className="w-5 h-5 text-gray-500" />
          <div className="flex gap-2">
            {statuses.map(status => (
              <button
                key={status}
                onClick={() => handleStatusFilter(status)}
                className={`px-3 py-1 rounded-full text-sm ${
                  filterStatus.includes(status)
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)}
              </button>
            ))}
          </div>
        </div>
        
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="px-3 py-1 border rounded-lg text-sm"
        >
          <option value="dueDate">Date d'échéance</option>
          <option value="budget">Budget</option>
          <option value="priority">Priorité</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTasks.map(task => (
          <TaskCard key={task.id} task={task} />
        ))}
      </div>
    </div>
  );
};

export default TaskList;