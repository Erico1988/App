import React from 'react';
import { 
  Home, 
  FileText, 
  Users, 
  Settings, 
  Calendar,
  BarChart,
  FileCheck,
  AlertCircle
} from 'lucide-react';

const Sidebar = () => {
  const menuItems = [
    { icon: Home, label: 'Tableau de bord', path: '/' },
    { icon: FileText, label: 'Marchés', path: '/procedures' },
    { icon: Calendar, label: 'Planning', path: '/planning' },
    { icon: Users, label: 'Équipe', path: '/team' },
    { icon: BarChart, label: 'Rapports', path: '/reports' },
    { icon: FileCheck, label: 'Validation', path: '/validation' },
    { icon: AlertCircle, label: 'Alertes', path: '/alerts' },
    { icon: Settings, label: 'Paramètres', path: '/settings' },
  ];

  return (
    <div className="w-64 h-screen bg-gray-900 text-white fixed left-0 top-0">
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-8">ProcureTrack</h1>
        <nav>
          {menuItems.map((item) => (
            <a
              key={item.path}
              href={item.path}
              className="flex items-center gap-3 text-gray-300 hover:text-white hover:bg-gray-800 rounded-lg p-3 transition-colors"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </a>
          ))}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;