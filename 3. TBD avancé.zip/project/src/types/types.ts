export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'draft' | 'review' | 'published' | 'awarded' | 'completed';
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  budget: number;
  assignedTo: string;
  documents: Document[];
  createdAt: string;
  updatedAt: string;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadedAt: string;
}

export interface User {
  id: string;
  name: string;
  role: 'admin' | 'manager' | 'user';
  avatar: string;
}